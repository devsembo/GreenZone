<?php

// Abrir sessão
session_start();

// carregar o autoload
require_once('../vendor/autoload.php');

// carrega o sistemas de rotas 
require_once('../core/rotas.php');